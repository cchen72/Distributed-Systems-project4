package ds.edu.cmu.project4;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * @author Chaofan Chen
 * Andrew ID: chaofanc
 *
 * This class is used to find the cheapest game on Steam, given a keyword from user input
 * It uses the CheapShark API to find the cheapest game
 **/
public class CheapestGame extends AppCompatActivity {

    CheapestGame me = this;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final CheapestGame ma = this;

        /*
         * Find the "submit" button, and add a listener to it
         */
        Button submitButton = (Button)findViewById(R.id.submit);

        // Add a listener to the submit button
        submitButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View viewParam) {
                //Get a keyword from user under ID searchTerm
                String keyword = ((EditText)findViewById(R.id.keyword)).getText().toString();
                System.out.println("keyword = " + keyword);

                if(keyword.trim().equals("")){
                    TextView msgView = findViewById(R.id.statusMsg);
                    msgView.setText("You can't enter nothing!");
                    msgView.setVisibility(View.VISIBLE);
                    return;
                }

                // Done asynchronously in another thread.
                // It calls cg.pictureReady() and cg.textReady() in this thread when complete.
                FetchData fd = new FetchData();
                fd.search(keyword, me, ma);
            }
        });
    }

    /*
     * This is called by the GetPicture object when the picture is ready.
     * This allows for passing back the Bitmap picture for updating the ImageView
     */
    public void pictureReady(Bitmap picture) {
        ImageView pictureView = (ImageView)findViewById(R.id.imageView);
        TextView searchView = (EditText)findViewById(R.id.keyword);
        TextView msgView = (TextView) findViewById(R.id.statusMsg);
//        if (picture != null) {
        // since we have handle null response in servlet, if there is null data,
        // servlet will return a file-not-found image url.
        pictureView.setImageBitmap(picture);
        msgView.setText("Find a game with keyword: " + searchView.getText() +"!");
        msgView.setVisibility(View.VISIBLE);
        pictureView.setVisibility(View.VISIBLE);
//        } else {
//            pictureView.setImageResource(R.mipmap.ic_launcher);
//            msgView.setText("Sorry, I could not find a picture of a " + searchView.getText());
//            msgView.setVisibility(View.VISIBLE);
//            System.out.println("No picture");
//            pictureView.setVisibility(View.INVISIBLE);
//        }
        searchView.setText("");
        pictureView.invalidate();
    }

    public void textReady(String gameName, String steamID, String price){
        TextView msgView = (TextView) findViewById(R.id.statusMsg);
        TextView dataView = (TextView) findViewById(R.id.gameData);

        // construct the display data
        StringBuilder sb = new StringBuilder();
        sb.append("Game Name: " + gameName);
        sb.append("\n");
        sb.append("Steam ID: " + steamID);
        sb.append("\n");
        sb.append("Cheapest Price: $" + price);
        String displayStr = sb.toString();

        // set the view
        dataView.setText(displayStr);
        msgView.setText("Game is found, picture is loading");

        msgView.setVisibility(View.VISIBLE);
        dataView.setVisibility(View.VISIBLE);
    }
}