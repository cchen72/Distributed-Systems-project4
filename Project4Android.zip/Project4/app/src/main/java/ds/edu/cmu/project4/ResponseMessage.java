package ds.edu.cmu.project4;

/**
 * @author Chaofan Chen
 * Andrew ID: chaofanc
 *
 * This is the class that the model use to generate the response and send back to the Android application.
 **/

class ResponseMessage {
    private String gameName;
    private String steamAppID;
    private String cheapestPrice;
    private String pictureURL;

    /**
     * Constructor
     * @param gameName
     * @param steamAppID
     * @param cheapestPrice
     * @param pictureURL
     */
    public ResponseMessage(String gameName, String steamAppID, String cheapestPrice, String pictureURL) {
        this.gameName = gameName;
        this.steamAppID = steamAppID;
        this.cheapestPrice = cheapestPrice;
        this.pictureURL = pictureURL;
    }

    public String getGameName() {
        return gameName;
    }

    public void setGameName(String gameName) {
        this.gameName = gameName;
    }

    public String getSteamAppID() {
        return steamAppID;
    }

    public void setSteamAppID(String steamAppID) {
        this.steamAppID = steamAppID;
    }

    public String getCheapestPrice() {
        return cheapestPrice;
    }

    public void setCheapestPrice(String cheapestPrice) {
        this.cheapestPrice = cheapestPrice;
    }

    public String getPictureURL() {
        return pictureURL;
    }

    public void setPictureURL(String pictureURL) {
        this.pictureURL = pictureURL;
    }
}