package ds.edu.cmu.project4;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.annotation.RequiresApi;

import com.google.gson.Gson;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

/**
 * @author Chaofan Chen
 * Andrew ID: chaofanc
 *
 * This class is used to fetch data from the CheapShark API
 * It is used by the CheapestGame class
 */
public class FetchData {
    CheapestGame cg = null;   // for callback
    String keyword = null;       // search CheapShark for this word
    // fields to store return result
    String gameName = null;
    String steamID = null;
    String price = null;
    Bitmap picture = null;

    public void search(String keyword, Activity activity, CheapestGame cg){
        this.cg = cg;
        this.keyword = keyword;
        new pictureBackgroundTask(activity).execute();
    }

    private class pictureBackgroundTask {

        private Activity activity;

        public pictureBackgroundTask(Activity activity) {this.activity = activity;}

        private void startBackground() {
            new Thread(new Runnable() {
                @Override
                public void run() {

                    doInBackground();

                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {onPostExecute();}
                    });
                }
            }).start();
        }

        private void execute() {startBackground();}

        private void onPostExecute(){
            cg.textReady(gameName, steamID, price);
            cg.pictureReady(picture);
        }

        private void doInBackground() {
            String preData = search(keyword);
            processData(preData);
        }

        private void processData(String preData) {
            // deserialize the data
            Gson gson = new Gson();
            ResponseMessage responseMessage = gson.fromJson(preData, ResponseMessage.class);
            gameName = responseMessage.getGameName();
            steamID = responseMessage.getSteamAppID();
            price = responseMessage.getCheapestPrice();
            try {
                picture = getRemoteImage(new URL(responseMessage.getPictureURL()));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
        }


        private String search(String keyword) {
            HttpURLConnection conn = null;
            String response = "";
            int status;

            // Call our own servlet to get the web page containing image URL's of the search term
            try {
                // create the URL
                URL url = new URL("https://cchen72-automatic-space-train-p95jggxg49frpg5-8080.preview.app.github.dev/api-getCheapestGame?keyword="+keyword);
                // connect to the servlet
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
                conn.setRequestProperty("Accept", "text/plain");

                // wait for response
                status = conn.getResponseCode();

                System.out.println(url.toString());

                if (status == 200) {
                    System.out.println("Successfully Connect to the Servlet!");
                    // get the response from servlet server
                    StringBuilder sb = new StringBuilder();
                    Scanner scanner = new Scanner(url.openStream());
                    // read response body
                    while (scanner.hasNext()) {
                        sb.append(scanner.nextLine());
                    }
                    System.out.println(sb);
                    response = sb.toString();
                    scanner.close();
                } else if (status == 400) {
                    throw new RuntimeException("404 NOT FOUND");
                } else {
                    throw new RuntimeException("Unknown Error");
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return response;
        }

        /*
         * Given a URL referring to an image, return a bitmap of that image
         */
        @RequiresApi(api = Build.VERSION_CODES.P)
        private Bitmap getRemoteImage(final URL url) {
            try {
                final URLConnection conn = url.openConnection();
                conn.connect();
                BufferedInputStream bis = new BufferedInputStream(conn.getInputStream());
                Bitmap bm = BitmapFactory.decodeStream(bis);
                return bm;
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }
    }

}