package ds.edu.cmu.project4task2;

/***
 * @author Chaofan Chen
 * Andrew ID: chaofanc
 *
 * This is the SteamGame class to store the Game information from CheapShark API
 */
public class SteamGame {
    private String gameID;
    private String steamAppID;
    private String cheapest;
    private String cheapestDealID;
    private String external;
    private String thumb;

    public SteamGame(String gameID, String steamAppID, String cheapest, String cheapestDealID, String external, String thumb) {
        this.gameID = gameID;
        this.steamAppID = steamAppID;
        this.cheapest = cheapest;
        this.cheapestDealID = cheapestDealID;
        this.external = external;
        this.thumb = thumb;
    }

    public String getGameID() {
        return gameID;
    }

    public void setGameID(String gameID) {
        this.gameID = gameID;
    }

    public String getSteamAppID() {
        return steamAppID;
    }

    public void setSteamAppID(String steamAppID) {
        this.steamAppID = steamAppID;
    }

    public String getCheapest() {
        return cheapest;
    }

    @Override
    public String toString() {
        return "SteamGame{" +
                "gameID='" + gameID + '\'' +
                ", steamAppID='" + steamAppID + '\'' +
                ", cheapest='" + cheapest + '\'' +
                ", cheapestDealID='" + cheapestDealID + '\'' +
                ", external='" + external + '\'' +
                ", thumb='" + thumb + '\'' +
                '}';
    }

    public void setCheapest(String cheapest) {
        this.cheapest = cheapest;
    }

    public String getCheapestDealID() {
        return cheapestDealID;
    }

    public void setCheapestDealID(String cheapestDealID) {
        this.cheapestDealID = cheapestDealID;
    }

    public String getExternal() {
        return external;
    }

    public void setExternal(String external) {
        this.external = external;
    }

    public String getThumb() {
        return thumb;
    }

    public void setThumb(String thumb) {
        this.thumb = thumb;
    }
}
