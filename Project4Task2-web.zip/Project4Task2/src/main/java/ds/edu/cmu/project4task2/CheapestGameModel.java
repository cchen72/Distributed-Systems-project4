package ds.edu.cmu.project4task2;

import com.google.gson.Gson;
import com.mongodb.client.*;
import org.bson.Document;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

/***
 * @author Chaofan Chen
 * Andrew ID: chaofanc
 *
 * This is the Model of the application. The model will send request and receive response from CheapShark API.
 * Processing the information and store the log information into MongoDB.
 * Also, it received request from client (Android)
 * and reply the necessary information back to the clinet.
 */
public class CheapestGameModel {

    /***
     * This method is to prepare the response contained with needed information.
     * First, it will use the keyword to call the doGet() method to access the third-party API,
     * the API server will return the information through JSON format of String,
     * it will store these information into a SteamGame object.
     * Finally, it will create the response message which only carries the necessary data.
     * @param keyword the searching keyword
     * @return a ResponseMessage carried the needed info
     */
    public ResponseMessage generateResponse(String keyword) {


        SteamGame sg = doGet(keyword);
        // construct the responseMessage
        String officialName = sg.getExternal();
        String steamID = sg.getSteamAppID();
        String price = sg.getCheapest();
        String pictureURL = sg.getThumb();
        ResponseMessage responseMessage = new ResponseMessage(officialName, steamID, price, pictureURL);
        // return the object
        return responseMessage;
    }

    /***
     * This method is to return a SteamGame object based on Json response from CheapShark API
     * @param keyword the search keyword from client side
     * @return a SteamGame object contained with all the needed information
     */
    private SteamGame doGet(String keyword) {
        HttpURLConnection conn;
        int status = 0;
        URL url = null;
        SteamGame steamGame;

        try {
            // preparation to connect the API
            String requestTime = String.valueOf(System.currentTimeMillis());
            url = new URL("https://www.cheapshark.com/api/1.0/games?&exact=0&limit=1&title=" + keyword);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "text/plain; charset=utf-8");
            conn.setRequestProperty("Accept", "text/plain");

            // connect to the API
            conn.connect();

            // wait for response from API server,
            // store the stateCode into result
            status = conn.getResponseCode();

            if (status != 200) {
                String responseTime = String.valueOf(System.currentTimeMillis());
                // record log
                makeLog(keyword, "", "", "",
                        "", String.valueOf(status), requestTime, responseTime);
                throw new RuntimeException("Status: " + status);
            } else {
                System.out.println("Successfully Connect!");

                // get the result from API server
                StringBuilder response = new StringBuilder();
                Scanner scanner = new Scanner(url.openStream());
                // read response body
                while (scanner.hasNext()) {
                    response.append(scanner.nextLine());
                }
                System.out.println(response);
                scanner.close();

                // if no game found, return a null game
                // else return the game
                if (response.toString().equals("[]")) {
                    steamGame = new SteamGame("", "", "0.0",
                            "","Not Found","https://cdn-icons-png.flaticon.com/128/2748/2748558.png");
                } else {
                    JSONArray jsonArray = new JSONArray(response.toString());
                    JSONObject jsonObject = (JSONObject) jsonArray.get(0);
                    System.out.println("Object: " + jsonObject.toString());
                    Gson gson = new Gson();
                    steamGame = gson.fromJson(jsonObject.toString(), SteamGame.class);
                }
                String responseTime = String.valueOf(System.currentTimeMillis());
                // Record log to the DB
                makeLog(keyword, steamGame.getSteamAppID(), steamGame.getExternal(), steamGame.getCheapest(),
                        steamGame.getThumb(), String.valueOf(status), requestTime, responseTime);
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return steamGame;
    }

    /***
     * Making a log and record it into MongoDB.
     * @param keyword searching keyword.
     * @param steamID steam id
     * @param gameName game official name
     * @param price the cheapest price
     * @param url game image url
     * @param status status
     * @param t0 request time
     * @param t1 response time
     */
    public void makeLog(String keyword, String steamID, String gameName, String price, String url,
                        String status, String t0, String t1) {

        // connect to Mongo DB
        String uri = "mongodb://cchen72:ccf15167031360@ac-jsmb9l6-shard-00-00.bttxcrf.mongodb.net:27017,ac-jsmb9l6-shard-00-01.bttxcrf.mongodb.net:27017,ac-jsmb9l6-shard-00-02.bttxcrf.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";

//        String uri = "mongodb://cchen72:ccf15167031360@ac-kau5gna-shard-00-00.jrr62cd.mongodb.net:27017,ac-kau5gna-shard-00-01.jrr62cd.mongodb.net:27017,ac-kau5gna-shard-00-02.jrr62cd.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase db = mongoClient.getDatabase("CheapestGameAppDB");

        // Check whether there is a log table
        boolean collectionExists = db.listCollectionNames().into(new ArrayList()).contains("AppLog");
        // If there is no log table, creat a table
        if (!collectionExists) {
            db.createCollection("AppLog");
        }

        MongoCollection table = db.getCollection("AppLog");
        System.out.println("MongoDB connection succeed, connect to the App logs table");
        // create the document
        Document document = new Document();
        document.append("keyword", keyword);
        document.append("steam_id", steamID);
        document.append("game_name", gameName);
        document.append("price", price);
        document.append("picture_url", url);
        document.append("status_code", status);
        document.append("request_time", t0);
        document.append("response_time", t1);
        // Insert document into the table
        table.insertOne(document);
    }

    /***
     * This method is to access the MongoDB and retrieve the previous log history.
     * @return all the log records
     */
    private FindIterable<Document> getLog() {
        // connect to Mongo DB
        String uri = "mongodb://cchen72:ccf15167031360@ac-jsmb9l6-shard-00-00.bttxcrf.mongodb.net:27017,ac-jsmb9l6-shard-00-01.bttxcrf.mongodb.net:27017,ac-jsmb9l6-shard-00-02.bttxcrf.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
//        String uri = "mongodb://cchen72:ccf15167031360@ac-kau5gna-shard-00-00.jrr62cd.mongodb.net:27017,ac-kau5gna-shard-00-01.jrr62cd.mongodb.net:27017,ac-kau5gna-shard-00-02.jrr62cd.mongodb.net:27017/test?w=majority&retryWrites=true&tls=true&authMechanism=SCRAM-SHA-1";
        MongoClient mongoClient = MongoClients.create(uri);
        MongoDatabase db = mongoClient.getDatabase("CheapestGameAppDB");

        // get the table
        MongoCollection<Document> collection = db.getCollection("AppLog");
        // get the iterator
        FindIterable<Document> iterDoc = collection.find();

        return iterDoc;
    }

    /***
     * This is the method to generate the necessary string to display the dashboard.
     * There are four components that need to be generated and stored in an ArrayList.
     * Component1 is the logs.
     * Component2 is the top5 searching keyword and the times.
     * Component3 is the statistical data of the cheapest price.
     * Component4 is the average latency.
     * @return an ArrayList that contains with 4 String components
     */

    public ArrayList<String> getComponents() {
        // get the logs history
        FindIterable<Document> logs = getLog();
        Iterator it = logs.iterator();
        // list to store the different components
        ArrayList<String> list = new ArrayList<>();

        // map to store - Top 5 popular searching keyword
        HashMap<String, Integer> kwMap = new HashMap<>();
        // int array to store the price
        ArrayList<Double> allPriceList = new ArrayList<>();


        // use StringBuilder to store the logs
        StringBuilder sb = new StringBuilder();
        int logs_count = 0;
        int total_latency = 0;
        while (it.hasNext()) {
            Document currentLog = (Document) it.next();

            sb.append(currentLog.get("keyword").toString().toLowerCase());
            sb.append(",");
            sb.append(currentLog.get("steam_id"));
            sb.append(",");
            sb.append(currentLog.get("game_name"));
            sb.append(",");
            sb.append(currentLog.get("price"));
            sb.append(",");
            sb.append(currentLog.get("picture_url"));
            sb.append(",");
            sb.append(currentLog.get("status_code"));
            sb.append(",");
            sb.append(new Date(Long.parseLong(currentLog.get("request_time").toString())));
            sb.append(",");
            sb.append(new Date(Long.parseLong(currentLog.get("response_time").toString())));
            sb.append("\n");

            // Calculate the # of logs and the total latency
            logs_count++;
            total_latency += Long.parseLong(currentLog.get("response_time").toString()) - Long.parseLong(currentLog.get("request_time").toString());

            //Count appearance of the current keyword
            String kw = currentLog.get("keyword").toString().toLowerCase();
            if(kwMap.containsKey(kw)){
                kwMap.put(kw, kwMap.get(kw)+1);
            } else {
                kwMap.put(kw, 1);
            }

            // Get summary for prices
            // skip the not found log, do not record the price of not-found log
            if (!currentLog.get("price").toString().equals("0.0")) {
                allPriceList.add(Double.valueOf(currentLog.get("price").toString()));
            }

        }

        //Setting up the first statistic component
        String component1 = sb.toString();

        //Setting up the top 5 searching keywords.
        // The kwMap will store the <keyword, times>.
        // We are using another map called sortedMap to store the top 5 keyword and their times.
        //Source: https://www.digitalocean.com/community/tutorials/sort-hashmap-by-value-java
        ArrayList<Integer> kwEntryList = new ArrayList<>();
        LinkedHashMap<String, Integer> sortedMap = new LinkedHashMap<>();
        for(Map.Entry<String, Integer> entry : kwMap.entrySet()){
            kwEntryList.add(entry.getValue());
        }
        Collections.sort(kwEntryList, Collections.reverseOrder());
        for(int i = 0; i < 5; i++){
            for(Map.Entry<String,Integer> entry : kwMap.entrySet()){
                if(entry.getValue().equals(kwEntryList.get(i))){
                    sortedMap.put(entry.getKey(), kwEntryList.get(i));
                }
            }
        }
        // Generate the component2 String
        StringBuilder sb2 = new StringBuilder();
        for(Map.Entry<String,Integer> entry : sortedMap.entrySet()){
            sb2.append(entry.getKey());
            sb2.append(",");
            sb2.append(entry.getValue().toString());
            sb2.append(",");
        }
        String top5AppearanceStr = sb2.toString();
        //component2 has the top 5 appearances of keywords
        String component2 = top5AppearanceStr.substring(0, top5AppearanceStr.length()-1);

        //Calculate the statistical data for component3
        // minimum price, 1st Quartile, average price, 3rd Quartile, maximum price
        Double minPrice, firstQPrice, avgPrice, thirdQPrice, maxPrice;
        Collections.sort(allPriceList);
        minPrice = allPriceList.get(0);
        firstQPrice = allPriceList.get((Integer)allPriceList.size()/4);
        Double priceSum = 0.0;
        for (Double x : allPriceList){
            priceSum += x;
        }
        avgPrice = priceSum / allPriceList.size();
        String avgPriceStr = String.format("%,.2f", avgPrice);
        thirdQPrice = allPriceList.get((Integer)allPriceList.size()/4*3);
        maxPrice = allPriceList.get(allPriceList.size()-1);

        //component3 has the detailed analysis for all prices
        String component3 =
                "$" + minPrice + "," +
                        "$" + firstQPrice + "," +
                        "$" + avgPriceStr + "," +
                        "$" + thirdQPrice + "," +
                        "$" + maxPrice;

        // component4 is the latency information
        double average_latency = (double) total_latency / logs_count;
        String component4 = String.format("%,.2f", average_latency);;

        // store the result to the list
        list.add(component1);
        list.add(component2);
        list.add(component3);
        list.add(component4);

        return list;
    }

}






