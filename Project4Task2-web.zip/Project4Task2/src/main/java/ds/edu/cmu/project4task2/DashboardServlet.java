package ds.edu.cmu.project4task2;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;

/***
 * @author Chaofan Chen
 * Andrew ID: chaofanc
 *
 * This is the servlet to display the dashboard.
 */

@WebServlet(name = "DashboardServlet",
        urlPatterns = {"/dashboard", ""})
public class DashboardServlet extends HttpServlet {

    CheapestGameModel cgm = null; // model to do the operation

    @Override
    public void init() {
        cgm = new CheapestGameModel();
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        // call to generate the components
        ArrayList<String> components = cgm.getComponents();
        // send to the front page
        request.setAttribute("components", components);
        RequestDispatcher view = request.getRequestDispatcher("dashboard.jsp");
        view.forward(request, response);

    }

    public void destroy() {
    }
}
