package ds.edu.cmu.project4task2;

import java.io.*;

import com.google.gson.Gson;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
/***
 * @author Chaofan Chen
 * Andrew ID: chaofanc
 *
 * This is the servlet to communicate with the Android app.
 * It first gets the searching keyword from the client's request.
 * Then it utilize the model to generate the response to the clinet.
 */

@WebServlet(name = "APIServlet",
        urlPatterns = {"/api-getCheapestGame"})
public class CheapestGameAPIServlet extends HttpServlet {

    CheapestGameModel cgm = null; // model to do the operation

    @Override
    public void init() {
        cgm = new CheapestGameModel();
    }

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        PrintWriter out = response.getWriter();

        // get the search keyword from client's request
        String keyword = request.getParameter("keyword");

        // since there is a game called "null" so here we use ==
        if (keyword == null || keyword.length() == 0) {
            out.println("Please enter a keyword for your request");
            out.flush();
            return;
        }

        // the model will try to call the CheapShark API
        // if success, get the response message from the model
        ResponseMessage responseMessage = cgm.generateResponse(keyword);

        // serialize the responseMessage
        Gson gson = new Gson();
        String responseJson = gson.toJson(responseMessage);

        // send back the response to client
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        out.println(responseJson);
        out.flush();
    }

    public void destroy() {
    }
}